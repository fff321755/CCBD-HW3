# Assignment 3
## Team Member
mx2237, Moxin Xu  
kw2963, Kuan-Hsuan Wu
## notebook for sagemaker
/notebook
## Lambda Function
/lambda
## Cloudformationl
cloudformation.yml
## Email Domain
monline.life
